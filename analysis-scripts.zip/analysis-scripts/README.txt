Clustering and rmsd/SASA/dihedral/gyration radius calculation input files are given for AtGrxC5.
The same protocol was applied to the other systems, with adapted residue and index masks.

All scripts are inputs for the cpptraj module of AMBER.